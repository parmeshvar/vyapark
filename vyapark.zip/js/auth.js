function nextStep(stepId) {
    // Hide all steps
    document.querySelectorAll('.auth-step').forEach(el => {
        el.classList.remove('active');
    });
    // Show target step
    document.getElementById(stepId).classList.add('active');
}

function prevStep(stepId) {
    nextStep(stepId);
}

function sendOTP() {
    const phoneInput = document.getElementById('phone-input').value;
    if(phoneInput.length < 10) {
        alert("Please enter a valid 10-digit phone number");
        return;
    }
    document.getElementById('display-phone').innerText = "+91 " + phoneInput;
    nextStep('step-otp');
    
    // Auto focus first OTP box
    setTimeout(() => {
        document.querySelector('.otp-box').focus();
    }, 100);
}

function verifyOTP() {
    // In a real app, verify with Firebase here
    nextStep('step-role');
}

// Auto move focus in OTP boxes
document.querySelectorAll('.otp-box').forEach((box, index, list) => {
    box.addEventListener('input', (e) => {
        if(e.target.value.length === 1 && index < list.length - 1) {
            list[index + 1].focus();
        }
    });
    box.addEventListener('keydown', (e) => {
        if(e.key === 'Backspace' && e.target.value === '' && index > 0) {
            list[index - 1].focus();
        }
    });
});

let selectedRole = '';
function selectRole(role) {
    selectedRole = role;
}

function finishSetup() {
    alert("Profile setup complete! Welcome to Vyapark.");
    // Redirect to home page
    window.location.href = 'index.html';
}
