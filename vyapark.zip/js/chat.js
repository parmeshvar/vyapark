document.addEventListener('DOMContentLoaded', () => {
    // Render Chat List if on chats.html
    const chatListContainer = document.getElementById('chat-list');
    if (chatListContainer) {
        const chats = [
            {
                id: 1,
                name: "Tech Store Delhi",
                msg: "Yes, we do same-day delivery within...",
                time: "10:48 AM",
                avatar: "https://ui-avatars.com/api/?name=TS&background=6366f1&color=fff",
                unread: 0,
                online: true
            },
            {
                id: 2,
                name: "Fashion Hub",
                msg: "Is this shirt available in XL?",
                time: "Yesterday",
                avatar: "https://ui-avatars.com/api/?name=FH&background=ec4899&color=fff",
                unread: 2,
                online: false
            },
            {
                id: 3,
                name: "Gadget Galaxy",
                msg: "Okay, I will process the order.",
                time: "Mon",
                avatar: "https://ui-avatars.com/api/?name=GG&background=10b981&color=fff",
                unread: 0,
                online: true
            }
        ];

        chats.forEach(chat => {
            const el = document.createElement('div');
            el.className = 'chat-list-item';
            el.onclick = () => window.location.href = 'chat-room.html';
            
            el.innerHTML = `
                <div class="cli-avatar-wrapper">
                    <img src="${chat.avatar}" alt="${chat.name}" class="cli-avatar">
                    ${chat.online ? '<div class="online-dot"></div>' : ''}
                </div>
                <div class="cli-content">
                    <div class="cli-top">
                        <h4>${chat.name}</h4>
                        <span class="cli-time">${chat.time}</span>
                    </div>
                    <div class="cli-bottom">
                        <p class="cli-msg ${chat.unread > 0 ? 'unread' : ''}">${chat.msg}</p>
                        ${chat.unread > 0 ? `<div class="unread-badge">${chat.unread}</div>` : ''}
                    </div>
                </div>
            `;
            chatListContainer.appendChild(el);
        });
    }

    // Scroll to bottom of chat room automatically
    const messagesContainer = document.getElementById('messages-container');
    if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
});

function handleEnter(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('msg-input');
    const msg = input.value.trim();
    if (msg === '') return;

    const messagesContainer = document.getElementById('messages-container');
    
    // Create Message Element
    const msgHTML = `
        <div class="message msg-sent" style="animation: slideIn 0.2s ease">
            <div class="msg-bubble">
                <p>${msg}</p>
                <span class="msg-time">Just now <i class="fa-solid fa-check text-primary"></i></span>
            </div>
        </div>
    `;
    
    messagesContainer.insertAdjacentHTML('beforeend', msgHTML);
    input.value = '';
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Simulate Seller Reply after 1.5 seconds
    setTimeout(() => {
        const replyHTML = `
            <div class="message msg-received" style="animation: slideIn 0.2s ease">
                <div class="msg-bubble">
                    <p>Got it! Is there anything else you need to know?</p>
                    <span class="msg-time">Just now</span>
                </div>
            </div>
        `;
        messagesContainer.insertAdjacentHTML('beforeend', replyHTML);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }, 1500);
}
