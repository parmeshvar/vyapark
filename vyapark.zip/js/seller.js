document.addEventListener('DOMContentLoaded', () => {
    // Initialize Dashboard Tab by default
    switchTab('dashboard', document.querySelector('.nav-item.active'));
});

let salesChartInstance = null;

function switchTab(tabId, navElement) {
    // Update Nav UI
    document.querySelectorAll('.bottom-nav .nav-item').forEach(el => el.classList.remove('active'));
    if(navElement) {
        navElement.classList.add('active');
    }

    // Get Content Area
    const mainContent = document.getElementById('main-content');
    
    // Get Template
    const template = document.getElementById(`tpl-${tabId}`);
    if (template) {
        // Clear main content and inject template
        mainContent.innerHTML = template.innerHTML;
        
        // Tab Specific Initialization
        if (tabId === 'dashboard') {
            initChart();
        }
    }
}

function initChart() {
    const ctx = document.getElementById('salesChart');
    if (!ctx) return;
    
    if (salesChartInstance) {
        salesChartInstance.destroy();
    }

    salesChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Sales (₹)',
                data: [1200, 1900, 1500, 2200, 1800, 2800, 2500],
                borderColor: '#6366f1',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true, display: false },
                x: { grid: { display: false } }
            }
        }
    });
}

window.showMasterProducts = function(val) {
    const grid = document.getElementById('master-products-grid');
    if (val.length > 2) {
        grid.style.display = 'grid';
    } else {
        grid.style.display = 'none';
    }
}

window.showCustomForm = function() {
    document.getElementById('add-product-form').style.display = 'block';
    document.getElementById('prod-title').value = '';
    document.getElementById('prod-category').value = 'Electronics';
    document.getElementById('prod-mrp').value = '';
    
    // Reset image area
    const imgArea = document.getElementById('product-img-preview');
    imgArea.innerHTML = `<i class="fa-solid fa-cloud-arrow-up"></i>
                         <p>Upload Image</p>
                         <span style="font-size:11px; color:var(--text-muted);">Auto-resize & Compress</span>`;
    imgArea.onclick = () => document.getElementById('product-image-upload').click();
}

window.selectMasterProduct = function(title, category, imgUrl, mrp) {
    // Show form
    document.getElementById('add-product-form').style.display = 'block';
    
    // Fill fields
    document.getElementById('prod-title').value = title;
    document.getElementById('prod-category').value = category;
    document.getElementById('prod-mrp').value = mrp;
    
    // Replace upload UI with image preview
    const imgArea = document.getElementById('product-img-preview');
    imgArea.innerHTML = `<img src="${imgUrl}" style="width:100px; height:100px; border-radius:8px; object-fit:cover;">
                         <p style="margin-top:8px; font-size:12px; color:var(--success); font-weight:600;"><i class="fa-solid fa-circle-check"></i> Image Auto-selected</p>`;
                         
    // Scroll to form
    setTimeout(() => {
        document.getElementById('add-product-form').scrollIntoView({behavior: "smooth"});
    }, 100);
}

// Client-side Image Compression
window.handleImageUpload = function(event) {
    const file = event.target.files[0];
    if (!file) return;

    const imgArea = document.getElementById('product-img-preview');
    imgArea.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-primary"></i><p style="margin-top:8px;">Compressing...</p>`;
    
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function(e) {
        const img = new Image();
        img.src = e.target.result;
        img.onload = function() {
            const canvas = document.createElement('canvas');
            const MAX_WIDTH = 800; // Auto-resize limit
            const MAX_HEIGHT = 800;
            let width = img.width;
            let height = img.height;

            if (width > height) {
                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }
            } else {
                if (height > MAX_HEIGHT) {
                    width *= MAX_HEIGHT / height;
                    height = MAX_HEIGHT;
                }
            }
            
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            // Compress as JPEG with 70% quality
            const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);

            // Update UI with compressed preview
            imgArea.innerHTML = `<img src="${compressedDataUrl}" style="width:100px; height:100px; border-radius:8px; object-fit:cover;">
                                 <p style="margin-top:8px; font-size:12px; color:var(--success); font-weight:600;"><i class="fa-solid fa-compress"></i> Resized & Compressed</p>`;
            imgArea.onclick = null; // Remove click to avoid accidental re-upload
        }
    }
}
